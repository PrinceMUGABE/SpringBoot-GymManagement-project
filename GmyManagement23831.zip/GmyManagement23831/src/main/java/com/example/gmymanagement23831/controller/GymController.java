package com.example.gmymanagement23831.controller;

import com.example.gmymanagement23831.exception.ResouceNotFoundException;
import com.example.gmymanagement23831.model.GymMember;
import com.example.gmymanagement23831.dao.GymDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/gym")
public class GymController {
    @Autowired
    private GymDao gymRepository;
    @GetMapping
    public List<GymMember> getAllGyms(){
        return  gymRepository.findAll();
    }
    @PostMapping
    public GymMember createGym(@RequestBody GymMember gym){
        return gymRepository.save(gym);
    }
    @GetMapping("{gymId}")
    public ResponseEntity<GymMember> getGymById(@PathVariable String gymId){
        GymMember employees = gymRepository.findById(gymId).orElseThrow(() -> new ResouceNotFoundException("Car not exist with platecnumber:" + gymId));
        return ResponseEntity.ok(employees);
    }
    @PutMapping("{gymId}")
    public ResponseEntity<GymMember> updateGyms(@PathVariable String gymId, @RequestBody GymMember gymDetails){
        GymMember gym = gymRepository.findById(gymId).orElseThrow(() -> new ResouceNotFoundException("Car not exist with plate number:" + gymId));

        gym.setEmail(gymDetails.getEmail());
        gym.setMembership_type(gymDetails.getMembership_type());
        gym.setName(gymDetails.getName());
        gymRepository.save(gym);
        return ResponseEntity.ok(gym);
    }
    @DeleteMapping("{gymId}")
    public ResponseEntity<HttpStatus> deleteGym(@PathVariable  String gymId){

        GymMember GymDelete = gymRepository.findById(gymId).orElseThrow(() -> new ResouceNotFoundException("car not exist with plate number :" + gymId));
        gymRepository.delete(GymDelete);
        return  new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }

}
