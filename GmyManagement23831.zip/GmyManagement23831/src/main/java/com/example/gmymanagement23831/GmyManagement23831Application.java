package com.example.gmymanagement23831;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GmyManagement23831Application {

    public static void main(String[] args) {
        SpringApplication.run(GmyManagement23831Application.class, args);
    }

}
