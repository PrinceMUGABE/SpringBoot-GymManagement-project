package com.example.gmymanagement23831.dao;


import com.example.gmymanagement23831.model.GymMember;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GymDao extends JpaRepository<GymMember,String> {
}
