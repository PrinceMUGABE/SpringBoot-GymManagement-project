package com.example.gmymanagement23831.ServiceImplementation;

import com.example.gmymanagement23831.dao.GymDao;
import com.example.gmymanagement23831.model.GymMember;
import com.example.gmymanagement23831.service.GymService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GymServiceImplementation implements GymService {
    @Autowired
    GymDao dao;
    @Override
    public GymMember saveGym(GymMember gymMember) {
        return dao.save(gymMember);
    }

    @Override
    public List<GymMember> displayGyms() {
        return dao.findAll();
    }

    @Override
    public GymMember updateGym(GymMember gymMember) {
        GymMember savedGym = dao.findById(gymMember.getId()).orElse(null);
        if (savedGym!=null){
            savedGym.setEmail(gymMember.getEmail());
            savedGym.setName(gymMember.getName());
            savedGym.setEndDate(gymMember.getEndDate());
            savedGym.setStartDate(gymMember.getStartDate());
            savedGym.setMembership_type(gymMember.getMembership_type());
            return dao.save(savedGym);
        }
        return dao.save(gymMember);
    }

    @Override
    public GymMember findGymById(String gymMember) {
        return dao.findById(gymMember).orElse(null);
    }

    @Override
    public void deleteGym(String gymMember) {
        GymMember savedGym = dao.findById(gymMember).orElse(null);
        if (savedGym!=null){
            dao.delete(savedGym);
        }

    }
}
