package com.example.gmymanagement23831.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.Date;


@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class GymMember {
    @Id
    private String Id;
    private String name;
    private String email;
    private String membership_type;
    private String startDate;
    private String endDate;

}
