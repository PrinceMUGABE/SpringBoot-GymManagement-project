package com.example.gmymanagement23831.service;

import com.example.gmymanagement23831.dao.GymDao;
import com.example.gmymanagement23831.model.GymMember;

import java.util.List;

public interface GymService{
    GymMember saveGym(GymMember gymMember);
    List<GymMember> displayGyms();
    GymMember updateGym(GymMember gymMember);
    GymMember findGymById(String gymMember);
    void deleteGym(String gymMember);

}
