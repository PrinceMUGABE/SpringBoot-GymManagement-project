package com.example.gmymanagement23831;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GmyManagement23831ApplicationTests {

    @Test
    void contextLoads() {
    }

}
